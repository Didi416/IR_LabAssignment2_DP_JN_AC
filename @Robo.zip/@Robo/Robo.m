classdef Robo < RobotBaseClass

    properties(Access = public)   
        plyFileNameStem = 'Robo';
    end
    
    
    methods
%% Constructor
function self = Robo(baseTr)
            
    baseTr = transl(0.3, 1.65, 0.75);
    %baseTr = transl(0,0,0);

    self.CreateModel();
    self.model.base = self.model.base.T * baseTr;
    self.model.tool = self.toolTr;
    self.PlotAndColourRobot();
    drawnow
 end

%% CreateModel
        function CreateModel(self)
             link(1) = Link('d', 0.09, 'a', 0, 'alpha', pi/2, 'offset', 0, 'qlim', [deg2rad(-360), deg2rad(360)]);
             link(2) = Link('d', 0, 'a', -0.43, 'alpha', 0, 'offset', 0, 'qlim', [deg2rad(-90), deg2rad(90)]);
             link(3) = Link('d', 0, 'a', -0.39, 'alpha', 0, 'offset', 0, 'qlim', [deg2rad(-180), deg2rad(180)]);
             link(4) = Link('d', 0.11, 'a', 0, 'alpha', pi/2, 'offset', 0, 'qlim', [deg2rad(-360), deg2rad(360)]);
             link(5) = Link('d', 0.09, 'a', 0, 'alpha', -pi/2, 'offset', 0, 'qlim', [deg2rad(-180), deg2rad(180)]);
             link(6) = Link('d', 0.08, 'a', 0, 'alpha', 0, 'offset', 0, 'qlim', [deg2rad(-360), deg2rad(360)]);

            self.model = SerialLink(link,'name',self.name);     
            %self.model.teach()
        end    
    end
end